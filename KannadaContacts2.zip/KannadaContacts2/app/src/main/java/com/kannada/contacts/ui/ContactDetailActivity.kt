package com.kannada.contacts.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.bumptech.glide.Glide
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.kannada.contacts.R
import com.kannada.contacts.utils.ContactHolder

class ContactDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_detail)

        val contact = ContactHolder.currentContact ?: run { finish(); return }
        val displayName = ContactHolder.currentDisplayName

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = displayName

        // Avatar
        val ivPhoto = findViewById<ImageView>(R.id.ivDetailPhoto)
        val tvLetter = findViewById<TextView>(R.id.tvDetailLetter)

        if (contact.photoUri != null) {
            Glide.with(this).load(contact.photoUri).circleCrop().into(ivPhoto)
            ivPhoto.visibility = View.VISIBLE
            tvLetter.visibility = View.GONE
        } else {
            ivPhoto.visibility = View.GONE
            tvLetter.visibility = View.VISIBLE
            tvLetter.text = displayName.firstOrNull()?.uppercase() ?: "?"
        }

        // Show original name if translated
        val tvOriginal = findViewById<TextView>(R.id.tvOriginalName)
        if (displayName != contact.name) {
            tvOriginal.visibility = View.VISIBLE
            tvOriginal.text = "Original: ${contact.name}"
        } else {
            tvOriginal.visibility = View.GONE
        }

        // Phone numbers
        val phoneContainer = findViewById<LinearLayout>(R.id.phoneContainer)
        contact.phoneNumbers.forEach { phone ->
            val row = layoutInflater.inflate(R.layout.item_detail_row, phoneContainer, false)
            row.findViewById<ImageView>(R.id.ivRowIcon).setImageResource(android.R.drawable.ic_menu_call)
            row.findViewById<TextView>(R.id.tvRowValue).text = phone.number
            row.findViewById<TextView>(R.id.tvRowLabel).text = phone.type
            row.setOnClickListener {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${phone.number}")))
            }
            row.setOnLongClickListener {
                startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${phone.number}")))
                true
            }
            phoneContainer.addView(row)
        }

        // Emails
        val emailContainer = findViewById<LinearLayout>(R.id.emailContainer)
        contact.emails.forEach { email ->
            val row = layoutInflater.inflate(R.layout.item_detail_row, emailContainer, false)
            row.findViewById<ImageView>(R.id.ivRowIcon).setImageResource(android.R.drawable.ic_dialog_email)
            row.findViewById<TextView>(R.id.tvRowValue).text = email
            row.findViewById<TextView>(R.id.tvRowLabel).text = "Email"
            row.setOnClickListener {
                startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")))
            }
            emailContainer.addView(row)
        }

        // FAB call
        findViewById<FloatingActionButton>(R.id.fabCall).setOnClickListener {
            val number = contact.phoneNumbers.firstOrNull()?.number ?: return@setOnClickListener
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        }

        // FAB SMS
        findViewById<FloatingActionButton>(R.id.fabSms).setOnClickListener {
            val number = contact.phoneNumbers.firstOrNull()?.number ?: return@setOnClickListener
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")))
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { onBackPressedDispatcher.onBackPressed(); return true }
        return super.onOptionsItemSelected(item)
    }
}
