package com.kannada.contacts.ui

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.kannada.contacts.R
import com.kannada.contacts.adapter.ContactsAdapter
import com.kannada.contacts.adapter.buildSectionedList
import com.kannada.contacts.model.Contact
import com.kannada.contacts.utils.ContactHolder
import com.kannada.contacts.utils.SupportedLanguages
import com.kannada.contacts.viewmodel.ContactViewModel
import com.kannada.contacts.viewmodel.UiState

class MainActivity : AppCompatActivity() {

    private val vm: ContactViewModel by viewModels()
    private lateinit var adapter: ContactsAdapter

    private lateinit var rvContacts: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvEmpty: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvLangBtn: TextView
    private lateinit var etSearch: EditText
    private lateinit var chipFavorites: Chip
    private lateinit var fab: FloatingActionButton
    private lateinit var tvContactCount: TextView

    companion object {
        const val PERM_CONTACTS = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupAdapter()
        setupSearch()
        setupLanguageButton()
        setupFavoritesChip()
        setupFab()
        observeViewModel()
        checkPermissions()
    }

    private fun bindViews() {
        rvContacts = findViewById(R.id.rvContacts)
        progressBar = findViewById(R.id.progressBar)
        tvEmpty = findViewById(R.id.tvEmpty)
        tvStatus = findViewById(R.id.tvStatus)
        tvLangBtn = findViewById(R.id.tvLanguageBtn)
        etSearch = findViewById(R.id.etSearch)
        chipFavorites = findViewById(R.id.chipFavorites)
        fab = findViewById(R.id.fab)
        tvContactCount = findViewById(R.id.tvContactCount)
    }

    private fun setupAdapter() {
        adapter = ContactsAdapter(
            onClick = { contact -> openDetail(contact) },
            onCallClick = { contact -> call(contact) }
        )
        rvContacts.layoutManager = LinearLayoutManager(this)
        rvContacts.adapter = adapter
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { vm.search(s?.toString() ?: "") }
        })
    }

    private fun setupLanguageButton() {
        tvLangBtn.setOnClickListener { showLanguagePicker() }
    }

    private fun setupFavoritesChip() {
        chipFavorites.setOnClickListener { vm.toggleFavorites() }
    }

    private fun setupFab() {
        fab.setOnClickListener {
            startActivity(Intent(Intent.ACTION_INSERT).apply {
                type = "vnd.android.cursor.dir/contact"
            })
        }
    }

    private fun showLanguagePicker() {
        val langs = SupportedLanguages.list
        val names = langs.map { "${it.nativeName} (${it.displayName})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choose Display Language")
            .setItems(names) { _, idx ->
                val chosen = langs[idx]
                tvLangBtn.text = chosen.nativeName
                vm.switchLanguage(chosen)
            }
            .show()
    }

    private fun observeViewModel() {
        vm.uiState.observe(this) { state ->
            when (state) {
                is UiState.Loading -> {
                    progressBar.visibility = View.VISIBLE
                    rvContacts.visibility = View.GONE
                    tvEmpty.visibility = View.GONE
                    tvStatus.text = "Loading contacts..."
                    tvStatus.visibility = View.VISIBLE
                }
                is UiState.PermissionNeeded -> {
                    progressBar.visibility = View.GONE
                    tvStatus.text = "Contacts permission needed"
                }
                is UiState.Downloading -> {
                    progressBar.visibility = View.VISIBLE
                    tvStatus.text = "⬇ Downloading ${state.languageName} language model..."
                    tvStatus.visibility = View.VISIBLE
                }
                is UiState.Success -> {
                    progressBar.visibility = View.GONE
                    tvStatus.visibility = View.GONE

                    tvContactCount.text = "${state.contacts.size} contacts"

                    if (state.contacts.isEmpty()) {
                        rvContacts.visibility = View.GONE
                        tvEmpty.visibility = View.VISIBLE
                    } else {
                        rvContacts.visibility = View.VISIBLE
                        tvEmpty.visibility = View.GONE
                        val list = buildSectionedList(state.contacts) { vm.getDisplayName(it) }
                        adapter.submitList(list)
                    }
                }
                is UiState.Error -> {
                    progressBar.visibility = View.GONE
                    tvStatus.text = "⚠ ${state.message}"
                    tvStatus.visibility = View.VISIBLE
                    Toast.makeText(this, state.message, Toast.LENGTH_LONG).show()
                }
            }
        }

        vm.showFavoritesOnly.observe(this) { favOnly ->
            chipFavorites.isChecked = favOnly
            chipFavorites.text = if (favOnly) "★ Favorites ON" else "☆ Favorites"
        }
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            == PackageManager.PERMISSION_GRANTED) {
            vm.loadContacts()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), PERM_CONTACTS)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERM_CONTACTS && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            vm.loadContacts()
        } else {
            Toast.makeText(this, "Contacts permission is required", Toast.LENGTH_LONG).show()
        }
    }

    private fun openDetail(contact: Contact) {
        ContactHolder.currentContact = contact
        ContactHolder.currentDisplayName = vm.getDisplayName(contact)
        startActivity(Intent(this, ContactDetailActivity::class.java))
    }

    private fun call(contact: Contact) {
        val number = contact.phoneNumbers.firstOrNull()?.number ?: return
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
    }
}
