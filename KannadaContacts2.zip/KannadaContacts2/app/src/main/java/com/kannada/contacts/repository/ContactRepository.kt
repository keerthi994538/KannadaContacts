package com.kannada.contacts.repository

import android.content.Context
import android.provider.ContactsContract
import com.kannada.contacts.model.Contact
import com.kannada.contacts.model.PhoneNumber

class ContactRepository(private val context: Context) {

    fun getContacts(accountName: String? = null): List<Contact> {
        val contactMap = mutableMapOf<String, Contact>()

        // First pass: get basic contact info + starred
        val contactCursor = context.contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
                ContactsContract.Contacts.PHOTO_URI,
                ContactsContract.Contacts.STARRED
            ),
            null, null,
            ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " ASC"
        )

        contactCursor?.use {
            val idIdx = it.getColumnIndex(ContactsContract.Contacts._ID)
            val nameIdx = it.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
            val photoIdx = it.getColumnIndex(ContactsContract.Contacts.PHOTO_URI)
            val starredIdx = it.getColumnIndex(ContactsContract.Contacts.STARRED)

            while (it.moveToNext()) {
                val id = it.getString(idIdx) ?: continue
                val name = it.getString(nameIdx) ?: continue
                if (name.isBlank()) continue
                val photo = if (photoIdx >= 0) it.getString(photoIdx) else null
                val starred = if (starredIdx >= 0) it.getInt(starredIdx) == 1 else false

                contactMap[id] = Contact(
                    id = id,
                    name = name,
                    phoneNumbers = emptyList(),
                    emails = emptyList(),
                    photoUri = photo,
                    isFavorite = starred
                )
            }
        }

        // Second pass: get phone numbers
        val phoneCursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE
            ),
            null, null, null
        )

        phoneCursor?.use {
            val idIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val typeIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE)

            while (it.moveToNext()) {
                val id = it.getString(idIdx) ?: continue
                val number = it.getString(numIdx) ?: continue
                val typeInt = if (typeIdx >= 0) it.getInt(typeIdx) else ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                val typeLabel = when (typeInt) {
                    ContactsContract.CommonDataKinds.Phone.TYPE_HOME -> "Home"
                    ContactsContract.CommonDataKinds.Phone.TYPE_WORK -> "Work"
                    ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE -> "Mobile"
                    else -> "Phone"
                }

                val existing = contactMap[id] ?: continue
                contactMap[id] = existing.copy(
                    phoneNumbers = existing.phoneNumbers + PhoneNumber(number, typeLabel)
                )
            }
        }

        // Third pass: get emails
        val emailCursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                ContactsContract.CommonDataKinds.Email.ADDRESS
            ),
            null, null, null
        )

        emailCursor?.use {
            val idIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Email.CONTACT_ID)
            val emailIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS)

            while (it.moveToNext()) {
                val id = it.getString(idIdx) ?: continue
                val email = it.getString(emailIdx) ?: continue
                val existing = contactMap[id] ?: continue
                contactMap[id] = existing.copy(emails = existing.emails + email)
            }
        }

        // Only keep contacts with phone numbers
        return contactMap.values
            .filter { it.phoneNumbers.isNotEmpty() }
            .sortedBy { it.name }
    }

    fun getFavorites(): List<Contact> {
        return getContacts().filter { it.isFavorite }
    }

    fun getAccounts(): List<String> {
        val accounts = mutableSetOf<String>()
        val cursor = context.contentResolver.query(
            ContactsContract.RawContacts.CONTENT_URI,
            arrayOf(ContactsContract.RawContacts.ACCOUNT_NAME),
            null, null, null
        )
        cursor?.use {
            val idx = it.getColumnIndex(ContactsContract.RawContacts.ACCOUNT_NAME)
            while (it.moveToNext()) {
                val name = it.getString(idx) ?: continue
                if (name.isNotBlank()) accounts.add(name)
            }
        }
        return accounts.toList()
    }
}
