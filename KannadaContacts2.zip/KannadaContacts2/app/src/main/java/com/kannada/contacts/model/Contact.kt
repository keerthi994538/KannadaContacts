package com.kannada.contacts.model

data class Contact(
    val id: String,
    val name: String,
    val phoneNumbers: List<PhoneNumber>,
    val emails: List<String> = emptyList(),
    val photoUri: String? = null,
    val isFavorite: Boolean = false,
    val accountName: String = ""
)

data class PhoneNumber(
    val number: String,
    val type: String = "Mobile"
)
