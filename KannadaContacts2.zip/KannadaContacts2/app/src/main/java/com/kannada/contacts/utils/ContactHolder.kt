package com.kannada.contacts.utils

import com.kannada.contacts.model.Contact

object ContactHolder {
    var currentContact: Contact? = null
    var currentDisplayName: String = ""
}
