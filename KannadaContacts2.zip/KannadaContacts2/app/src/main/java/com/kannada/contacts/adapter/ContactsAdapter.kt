package com.kannada.contacts.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.kannada.contacts.R
import com.kannada.contacts.model.Contact

sealed class ListItem {
    data class Header(val letter: String) : ListItem()
    data class ContactItem(val contact: Contact, val displayName: String) : ListItem()
}

class ContactsAdapter(
    private val onClick: (Contact) -> Unit,
    private val onCallClick: (Contact) -> Unit
) : ListAdapter<ListItem, RecyclerView.ViewHolder>(DiffCallback()) {

    companion object {
        const val TYPE_HEADER = 0
        const val TYPE_CONTACT = 1
    }

    private val avatarColors = listOf(
        0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFE53935.toInt(),
        0xFFFF8F00.toInt(), 0xFF8E24AA.toInt(), 0xFF00ACC1.toInt(),
        0xFFF4511E.toInt(), 0xFF3949AB.toInt(), 0xFF00897B.toInt()
    )

    override fun getItemViewType(position: Int) = when (getItem(position)) {
        is ListItem.Header -> TYPE_HEADER
        is ListItem.ContactItem -> TYPE_CONTACT
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_HEADER -> HeaderVH(inflater.inflate(R.layout.item_section_header, parent, false))
            else -> ContactVH(inflater.inflate(R.layout.item_contact, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is ListItem.Header -> (holder as HeaderVH).bind(item.letter)
            is ListItem.ContactItem -> (holder as ContactVH).bind(item.contact, item.displayName)
        }
    }

    inner class ContactVH(view: View) : RecyclerView.ViewHolder(view) {
        private val ivPhoto: ImageView = view.findViewById(R.id.ivContactPhoto)
        private val tvLetter: TextView = view.findViewById(R.id.tvContactLetter)
        private val tvName: TextView = view.findViewById(R.id.tvContactName)
        private val tvPhone: TextView = view.findViewById(R.id.tvContactPhone)
        private val ivCall: ImageView = view.findViewById(R.id.ivCall)
        private val ivFav: ImageView = view.findViewById(R.id.ivFavorite)

        fun bind(contact: Contact, displayName: String) {
            tvName.text = displayName
            tvPhone.text = contact.phoneNumbers.firstOrNull()?.number ?: ""
            ivFav.visibility = if (contact.isFavorite) View.VISIBLE else View.GONE

            if (contact.photoUri != null) {
                Glide.with(itemView.context)
                    .load(contact.photoUri)
                    .circleCrop()
                    .placeholder(R.drawable.circle_bg)
                    .into(ivPhoto)
                ivPhoto.visibility = View.VISIBLE
                tvLetter.visibility = View.GONE
            } else {
                ivPhoto.visibility = View.GONE
                tvLetter.visibility = View.VISIBLE
                val letter = displayName.firstOrNull()?.uppercase() ?: "?"
                tvLetter.text = letter
                val colorIdx = (displayName.firstOrNull()?.code ?: 0) % avatarColors.size
                tvLetter.setBackgroundColor(avatarColors[colorIdx])
            }

            itemView.setOnClickListener { onClick(contact) }
            ivCall.setOnClickListener { onCallClick(contact) }
        }
    }

    class HeaderVH(view: View) : RecyclerView.ViewHolder(view) {
        private val tv: TextView = view.findViewById(R.id.tvSectionLetter)
        fun bind(letter: String) { tv.text = letter }
    }

    class DiffCallback : DiffUtil.ItemCallback<ListItem>() {
        override fun areItemsTheSame(a: ListItem, b: ListItem): Boolean {
            return when {
                a is ListItem.Header && b is ListItem.Header -> a.letter == b.letter
                a is ListItem.ContactItem && b is ListItem.ContactItem -> a.contact.id == b.contact.id
                else -> false
            }
        }
        override fun areContentsTheSame(a: ListItem, b: ListItem) = a == b
    }
}

fun buildSectionedList(contacts: List<Contact>, getName: (Contact) -> String): List<ListItem> {
    val result = mutableListOf<ListItem>()
    var lastHeader = ""
    for (contact in contacts) {
        val displayName = getName(contact)
        val header = displayName.firstOrNull()?.uppercase() ?: "#"
        if (header != lastHeader) {
            result.add(ListItem.Header(header))
            lastHeader = header
        }
        result.add(ListItem.ContactItem(contact, displayName))
    }
    return result
}
