package com.kannada.contacts.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.kannada.contacts.model.Contact
import com.kannada.contacts.repository.ContactRepository
import com.kannada.contacts.utils.Language
import com.kannada.contacts.utils.SupportedLanguages
import com.kannada.contacts.utils.TranslationManager
import com.google.mlkit.nl.translate.TranslateLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class UiState {
    object Loading : UiState()
    object PermissionNeeded : UiState()
    data class Downloading(val languageName: String) : UiState()
    data class Success(
        val contacts: List<Contact>,
        val translatedNames: Map<String, String>,
        val currentLanguage: Language
    ) : UiState()
    data class Error(val message: String) : UiState()
}

class ContactViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ContactRepository(application)
    val translationManager = TranslationManager()

    private val _uiState = MutableLiveData<UiState>(UiState.Loading)
    val uiState: LiveData<UiState> = _uiState

    private val _currentLanguage = MutableLiveData(SupportedLanguages.list[0]) // English default
    val currentLanguage: LiveData<Language> = _currentLanguage

    private val _showFavoritesOnly = MutableLiveData(false)
    val showFavoritesOnly: LiveData<Boolean> = _showFavoritesOnly

    private val _accounts = MutableLiveData<List<String>>(emptyList())
    val accounts: LiveData<List<String>> = _accounts

    private var allContacts: List<Contact> = emptyList()
    private val translatedNames = mutableMapOf<String, String>()
    private var searchQuery = ""

    fun loadContacts() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            try {
                allContacts = withContext(Dispatchers.IO) { repository.getContacts() }
                val accountList = withContext(Dispatchers.IO) { repository.getAccounts() }
                _accounts.value = accountList
                pushSuccess()
            } catch (e: Exception) {
                _uiState.value = UiState.Error(e.message ?: "Failed to load contacts")
            }
        }
    }

    fun switchLanguage(language: Language) {
        _currentLanguage.value = language
        translatedNames.clear()

        if (language.code == TranslateLanguage.ENGLISH) {
            pushSuccess()
            return
        }

        viewModelScope.launch {
            _uiState.value = UiState.Downloading(language.nativeName)
            val ready = translationManager.prepare(language.code)
            if (ready) {
                translateAllContacts()
            } else {
                _uiState.value = UiState.Error("Could not download ${language.displayName} language model. Check internet connection.")
                _currentLanguage.value = SupportedLanguages.list[0]
            }
        }
    }

    private suspend fun translateAllContacts() {
        val toTranslate = allContacts.filter { translatedNames[it.id] == null }
        for (contact in toTranslate) {
            val translated = translationManager.translate(contact.name)
            translatedNames[contact.id] = translated
        }
        pushSuccess()
    }

    fun search(query: String) {
        searchQuery = query
        pushSuccess()
    }

    fun toggleFavorites() {
        _showFavoritesOnly.value = !(_showFavoritesOnly.value ?: false)
        pushSuccess()
    }

    fun getDisplayName(contact: Contact): String {
        val lang = _currentLanguage.value
        return if (lang?.code != TranslateLanguage.ENGLISH) {
            translatedNames[contact.id] ?: contact.name
        } else {
            contact.name
        }
    }

    private fun pushSuccess() {
        val lang = _currentLanguage.value ?: SupportedLanguages.list[0]
        val favOnly = _showFavoritesOnly.value ?: false

        var filtered = allContacts
        if (favOnly) filtered = filtered.filter { it.isFavorite }
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.lowercase()
            filtered = filtered.filter { contact ->
                val displayName = getDisplayName(contact).lowercase()
                displayName.contains(q) || contact.name.lowercase().contains(q) ||
                contact.phoneNumbers.any { it.number.contains(q) }
            }
        }

        _uiState.value = UiState.Success(filtered, translatedNames.toMap(), lang)
    }

    override fun onCleared() {
        super.onCleared()
        translationManager.close()
    }
}
