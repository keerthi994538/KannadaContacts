package com.kannada.contacts.utils

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class Language(val code: String, val displayName: String, val nativeName: String)

object SupportedLanguages {
    val list = listOf(
        Language(TranslateLanguage.ENGLISH, "English", "English"),
        Language(TranslateLanguage.KANNADA, "Kannada", "ಕನ್ನಡ"),
        Language(TranslateLanguage.HINDI, "Hindi", "हिन्दी"),
        Language(TranslateLanguage.TAMIL, "Tamil", "தமிழ்"),
        Language(TranslateLanguage.TELUGU, "Telugu", "తెలుగు"),
        Language(TranslateLanguage.MALAYALAM, "Malayalam", "മലയാളം"),
        Language(TranslateLanguage.MARATHI, "Marathi", "मराठी"),
        Language(TranslateLanguage.BENGALI, "Bengali", "বাংলা")
    )
}

class TranslationManager {

    private var translator: Translator? = null
    private val cache = mutableMapOf<String, String>()
    var isReady = false
        private set
    var currentTargetLanguage: String = TranslateLanguage.ENGLISH
        private set

    suspend fun prepare(targetLang: String): Boolean {
        if (targetLang == TranslateLanguage.ENGLISH) {
            isReady = true
            currentTargetLanguage = targetLang
            return true
        }

        // Close previous translator
        translator?.close()
        cache.clear()
        isReady = false
        currentTargetLanguage = targetLang

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(targetLang)
            .build()

        translator = Translation.getClient(options)

        return suspendCancellableCoroutine { cont ->
            val conditions = DownloadConditions.Builder().build()
            translator!!.downloadModelIfNeeded(conditions)
                .addOnSuccessListener {
                    isReady = true
                    cont.resume(true)
                }
                .addOnFailureListener {
                    isReady = false
                    cont.resume(false)
                }
        }
    }

    suspend fun translate(text: String): String {
        if (!isReady || currentTargetLanguage == TranslateLanguage.ENGLISH) return text
        cache[text]?.let { return it }

        return suspendCancellableCoroutine { cont ->
            translator?.translate(text)
                ?.addOnSuccessListener { translated ->
                    cache[text] = translated
                    cont.resume(translated)
                }
                ?.addOnFailureListener {
                    cont.resume(text)
                } ?: cont.resume(text)
        }
    }

    fun getCached(text: String): String = cache[text] ?: text

    fun close() {
        translator?.close()
    }
}
