package com.kannada.contacts.utils

import com.kannada.contacts.model.Contact

object SectionBuilder {
    fun buildSectionedList(
        contacts: List<Contact>,
        getDisplayName: (Contact) -> String
    ): List<Any> {
        val result = mutableListOf<Any>()
        var lastHeader = ""

        // Favorites section
        val favorites = contacts.filter { it.isFavorite }
        if (favorites.isNotEmpty()) {
            result.add("★")
            result.addAll(favorites)
        }

        val nonFavorites = contacts.filter { !it.isFavorite }
        for (contact in nonFavorites) {
            val displayName = getDisplayName(contact)
            val firstChar = displayName.firstOrNull()?.uppercase() ?: "#"
            val header = if (firstChar[0].isLetter()) firstChar else "#"

            if (header != lastHeader) {
                result.add(header)
                lastHeader = header
            }
            result.add(contact)
        }

        return result
    }
}
