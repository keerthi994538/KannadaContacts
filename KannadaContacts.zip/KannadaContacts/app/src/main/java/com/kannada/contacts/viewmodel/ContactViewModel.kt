package com.kannada.contacts.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.kannada.contacts.model.Contact
import com.kannada.contacts.repository.ContactRepository
import com.kannada.contacts.utils.TranslationManager
import kotlinx.coroutines.launch

sealed class UiState {
    object Loading : UiState()
    object PermissionNeeded : UiState()
    object TranslatorDownloading : UiState()
    data class Success(val contacts: List<Contact>, val displayNames: Map<String, String>) : UiState()
    data class Error(val message: String) : UiState()
}

class ContactViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ContactRepository(application)
    val translationManager = TranslationManager()

    private val _uiState = MutableLiveData<UiState>(UiState.Loading)
    val uiState: LiveData<UiState> = _uiState

    private val _isKannadaMode = MutableLiveData(false)
    val isKannadaMode: LiveData<Boolean> = _isKannadaMode

    private val _searchQuery = MutableLiveData("")
    val searchQuery: LiveData<String> = _searchQuery

    private var allContacts: List<Contact> = emptyList()
    private val translatedNames = mutableMapOf<String, String>()

    fun loadContacts() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading
            try {
                allContacts = repository.getContacts()
                pushSuccess()
            } catch (e: Exception) {
                _uiState.value = UiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun prepareTranslator() {
        viewModelScope.launch {
            _uiState.value = UiState.TranslatorDownloading
            val ready = translationManager.prepare()
            if (!ready) {
                // Still show contacts, just without translation
            }
            pushSuccess()
        }
    }

    fun setKannadaMode(enabled: Boolean) {
        _isKannadaMode.value = enabled
        if (enabled && translationManager.isReady) {
            translateAll()
        } else {
            pushSuccess()
        }
    }

    private fun translateAll() {
        viewModelScope.launch {
            val toTranslate = allContacts.filter { translatedNames[it.id] == null }
            for (contact in toTranslate) {
                val translated = translationManager.translate(contact.name)
                translatedNames[contact.id] = translated
            }
            pushSuccess()
        }
    }

    fun search(query: String) {
        _searchQuery.value = query
        pushSuccess()
    }

    private fun pushSuccess() {
        val query = _searchQuery.value?.lowercase() ?: ""
        val isKannada = _isKannadaMode.value ?: false

        val filtered = if (query.isBlank()) {
            allContacts
        } else {
            allContacts.filter { contact ->
                val displayName = if (isKannada) translatedNames[contact.id] ?: contact.name else contact.name
                displayName.lowercase().contains(query) ||
                contact.phoneNumbers.any { it.number.contains(query) }
            }
        }

        _uiState.value = UiState.Success(filtered, translatedNames.toMap())
    }

    fun getDisplayName(contact: Contact): String {
        val isKannada = _isKannadaMode.value ?: false
        return if (isKannada) translatedNames[contact.id] ?: contact.name else contact.name
    }

    override fun onCleared() {
        super.onCleared()
        translationManager.close()
    }
}
