package com.kannada.contacts.repository

import android.content.Context
import android.provider.ContactsContract
import com.kannada.contacts.model.Contact
import com.kannada.contacts.model.PhoneNumber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ContactRepository(private val context: Context) {

    suspend fun getContacts(): List<Contact> = withContext(Dispatchers.IO) {
        val contactMap = mutableMapOf<String, ContactBuilder>()

        // Fetch phone numbers
        val phoneCursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE,
                ContactsContract.CommonDataKinds.Phone.PHOTO_URI,
                ContactsContract.CommonDataKinds.Phone.STARRED
            ),
            null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY + " COLLATE NOCASE ASC"
        )

        phoneCursor?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY)
            val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val typeIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE)
            val photoIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI)
            val starredIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.STARRED)

            while (cursor.moveToNext()) {
                val id = cursor.getString(idIdx) ?: continue
                val name = cursor.getString(nameIdx) ?: continue
                val number = cursor.getString(numberIdx) ?: continue
                val typeInt = cursor.getInt(typeIdx)
                val photo = cursor.getString(photoIdx)
                val starred = cursor.getInt(starredIdx) == 1

                val typeLabel = when (typeInt) {
                    ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE -> "Mobile"
                    ContactsContract.CommonDataKinds.Phone.TYPE_HOME -> "Home"
                    ContactsContract.CommonDataKinds.Phone.TYPE_WORK -> "Work"
                    else -> "Other"
                }

                val builder = contactMap.getOrPut(id) {
                    ContactBuilder(id, name, photo, starred)
                }
                builder.phones.add(PhoneNumber(number, typeLabel))
            }
        }

        // Fetch emails
        val emailCursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                ContactsContract.CommonDataKinds.Email.ADDRESS
            ),
            null, null, null
        )

        emailCursor?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.CONTACT_ID)
            val emailIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS)

            while (cursor.moveToNext()) {
                val id = cursor.getString(idIdx) ?: continue
                val email = cursor.getString(emailIdx) ?: continue
                contactMap[id]?.emails?.add(email)
            }
        }

        contactMap.values
            .map { it.toContact() }
            .sortedBy { it.name.lowercase() }
    }

    private data class ContactBuilder(
        val id: String,
        val name: String,
        val photoUri: String?,
        val isFavorite: Boolean,
        val phones: MutableList<PhoneNumber> = mutableListOf(),
        val emails: MutableList<String> = mutableListOf()
    ) {
        fun toContact() = Contact(id, name, phones, emails, photoUri, isFavorite)
    }
}
