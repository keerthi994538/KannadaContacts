package com.kannada.contacts.utils

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class TranslationManager {

    private var translatorEnToKn: Translator? = null
    private val cache = mutableMapOf<String, String>()
    var isReady = false
        private set

    suspend fun prepare(): Boolean = suspendCancellableCoroutine { cont ->
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.KANNADA)
            .build()

        translatorEnToKn = Translation.getClient(options)

        val conditions = DownloadConditions.Builder().build() // allow any network
        translatorEnToKn!!.downloadModelIfNeeded(conditions)
            .addOnSuccessListener {
                isReady = true
                cont.resume(true)
            }
            .addOnFailureListener {
                cont.resume(false)
            }
    }

    suspend fun translate(text: String): String {
        if (!isReady || text.isBlank()) return text

        // If text is already in Kannada script, return as-is
        if (isKannada(text)) return text

        cache[text]?.let { return it }

        return suspendCancellableCoroutine { cont ->
            translatorEnToKn?.translate(text)
                ?.addOnSuccessListener { translated ->
                    cache[text] = translated
                    cont.resume(translated)
                }
                ?.addOnFailureListener {
                    cont.resume(text) // fallback
                } ?: cont.resume(text)
        }
    }

    private fun isKannada(text: String): Boolean {
        return text.any { it.code in 0x0C80..0x0CFF }
    }

    fun getCached(text: String): String? = cache[text]

    fun close() {
        translatorEnToKn?.close()
    }
}
