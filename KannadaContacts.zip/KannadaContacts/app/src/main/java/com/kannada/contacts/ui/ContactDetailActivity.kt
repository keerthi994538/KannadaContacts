package com.kannada.contacts.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.kannada.contacts.R
import com.kannada.contacts.model.Contact

class ContactDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_detail)

        val contact = ContactHolder.currentContact ?: run { finish(); return }
        val displayName = ContactHolder.currentDisplayName

        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val collapsingToolbar = findViewById<CollapsingToolbarLayout>(R.id.collapsingToolbar)
        collapsingToolbar.title = displayName

        val avatar = findViewById<ImageView>(R.id.ivDetailAvatar)
        val avatarLetter = findViewById<TextView>(R.id.tvDetailAvatarLetter)

        // Avatar
        if (contact.photoUri != null) {
            Glide.with(this).load(contact.photoUri).into(avatar)
            avatar.visibility = View.VISIBLE
            avatarLetter.visibility = View.GONE
        } else {
            avatar.visibility = View.GONE
            avatarLetter.visibility = View.VISIBLE
            avatarLetter.text = displayName.firstOrNull()?.uppercase() ?: "?"
        }

        // Original name (show if different from display name)
        val tvOriginalName = findViewById<TextView>(R.id.tvOriginalName)
        if (displayName != contact.name) {
            tvOriginalName.visibility = View.VISIBLE
            tvOriginalName.text = "Also: ${contact.name}"
        } else {
            tvOriginalName.visibility = View.GONE
        }

        // Phone numbers
        val phoneContainer = findViewById<LinearLayout>(R.id.phoneContainer)
        contact.phoneNumbers.forEach { phone ->
            val rowView = layoutInflater.inflate(R.layout.item_detail_row, phoneContainer, false)
            rowView.findViewById<ImageView>(R.id.ivRowIcon).setImageResource(R.drawable.ic_phone)
            rowView.findViewById<TextView>(R.id.tvRowTitle).text = phone.number
            rowView.findViewById<TextView>(R.id.tvRowSubtitle).text = phone.type

            rowView.setOnClickListener {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${phone.number}"))
                startActivity(intent)
            }
            phoneContainer.addView(rowView)
        }

        // Emails
        val emailContainer = findViewById<LinearLayout>(R.id.emailContainer)
        contact.emails.forEach { email ->
            val rowView = layoutInflater.inflate(R.layout.item_detail_row, emailContainer, false)
            rowView.findViewById<ImageView>(R.id.ivRowIcon).setImageResource(R.drawable.ic_email)
            rowView.findViewById<TextView>(R.id.tvRowTitle).text = email
            rowView.findViewById<TextView>(R.id.tvRowSubtitle).text = "Email"
            rowView.setOnClickListener {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email"))
                startActivity(intent)
            }
            emailContainer.addView(rowView)
        }

        // FAB Call
        val fab = findViewById<FloatingActionButton>(R.id.fabCall)
        fab.setOnClickListener {
            val number = contact.phoneNumbers.firstOrNull()?.number ?: return@setOnClickListener
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
            startActivity(intent)
        }

        // SMS button
        val fabSms = findViewById<FloatingActionButton>(R.id.fabSms)
        fabSms.setOnClickListener {
            val number = contact.phoneNumbers.firstOrNull()?.number ?: return@setOnClickListener
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number"))
            startActivity(intent)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
