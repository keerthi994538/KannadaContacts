package com.kannada.contacts.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.kannada.contacts.R
import com.kannada.contacts.model.Contact

class ContactsAdapter(
    private val getDisplayName: (Contact) -> String,
    private val onClick: (Contact) -> Unit,
    private val onCallClick: (Contact) -> Unit
) : ListAdapter<Any, RecyclerView.ViewHolder>(DiffCallback()) {

    companion object {
        const val TYPE_HEADER = 0
        const val TYPE_CONTACT = 1
    }

    override fun getItemViewType(position: Int): Int {
        return when (getItem(position)) {
            is String -> TYPE_HEADER
            is Contact -> TYPE_CONTACT
            else -> TYPE_CONTACT
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            TYPE_HEADER -> {
                val view = LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_section_header, parent, false)
                HeaderViewHolder(view)
            }
            else -> {
                val view = LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_contact, parent, false)
                ContactViewHolder(view)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is HeaderViewHolder -> holder.bind(getItem(position) as String)
            is ContactViewHolder -> holder.bind(getItem(position) as Contact)
        }
    }

    inner class ContactViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val avatar: ImageView = itemView.findViewById(R.id.ivAvatar)
        private val avatarLetter: TextView = itemView.findViewById(R.id.tvAvatarLetter)
        private val name: TextView = itemView.findViewById(R.id.tvContactName)
        private val phone: TextView = itemView.findViewById(R.id.tvContactPhone)
        private val callBtn: ImageView = itemView.findViewById(R.id.ivCall)

        fun bind(contact: Contact) {
            val displayName = getDisplayName(contact)
            name.text = displayName
            phone.text = contact.phoneNumbers.firstOrNull()?.number ?: ""

            // Avatar setup
            if (contact.photoUri != null) {
                Glide.with(itemView.context)
                    .load(contact.photoUri)
                    .circleCrop()
                    .into(avatar)
                avatar.visibility = View.VISIBLE
                avatarLetter.visibility = View.GONE
            } else {
                avatar.visibility = View.GONE
                avatarLetter.visibility = View.VISIBLE
                avatarLetter.text = displayName.firstOrNull()?.uppercase() ?: "?"
                // Color based on first letter
                val colors = listOf(
                    0xFF1E88E5.toInt(), // blue
                    0xFF43A047.toInt(), // green
                    0xFFE53935.toInt(), // red
                    0xFFFF8F00.toInt(), // amber
                    0xFF8E24AA.toInt(), // purple
                    0xFF00ACC1.toInt(), // cyan
                    0xFFF4511E.toInt(), // deep orange
                    0xFF3949AB.toInt()  // indigo
                )
                val colorIndex = (displayName.firstOrNull()?.code ?: 0) % colors.size
                avatarLetter.setBackgroundColor(colors[colorIndex])
            }

            itemView.setOnClickListener { onClick(contact) }
            callBtn.setOnClickListener { onCallClick(contact) }
        }
    }

    class HeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val letter: TextView = itemView.findViewById(R.id.tvSectionLetter)
        fun bind(header: String) { letter.text = header }
    }

    class DiffCallback : DiffUtil.ItemCallback<Any>() {
        override fun areItemsTheSame(oldItem: Any, newItem: Any): Boolean {
            if (oldItem is Contact && newItem is Contact) return oldItem.id == newItem.id
            if (oldItem is String && newItem is String) return oldItem == newItem
            return false
        }
        override fun areContentsTheSame(oldItem: Any, newItem: Any): Boolean = oldItem == newItem
    }
}
