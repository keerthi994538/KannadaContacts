package com.kannada.contacts.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.kannada.contacts.R
import com.kannada.contacts.adapter.ContactsAdapter
import com.kannada.contacts.model.Contact
import com.kannada.contacts.utils.SectionBuilder
import com.kannada.contacts.viewmodel.ContactViewModel
import com.kannada.contacts.viewmodel.UiState

class MainActivity : AppCompatActivity() {

    private val viewModel: ContactViewModel by viewModels()

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var emptyView: TextView
    private lateinit var statusBar: TextView
    private lateinit var langToggle: com.google.android.material.switchmaterial.SwitchMaterial
    private lateinit var langLabel: TextView
    private lateinit var searchView: SearchView
    private lateinit var fab: FloatingActionButton
    private lateinit var adapter: ContactsAdapter

    companion object {
        const val PERMISSION_REQUEST = 101
        const val EXTRA_CONTACT_ID = "contact_id"
        const val EXTRA_IS_KANNADA = "is_kannada"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupViews()
        setupRecyclerView()
        observeViewModel()
        checkPermissions()
    }

    private fun setupViews() {
        recyclerView = findViewById(R.id.recyclerView)
        progressBar = findViewById(R.id.progressBar)
        emptyView = findViewById(R.id.tvEmpty)
        statusBar = findViewById(R.id.tvStatus)
        langToggle = findViewById(R.id.langToggle)
        langLabel = findViewById(R.id.tvLangLabel)
        searchView = findViewById(R.id.searchView)
        fab = findViewById(R.id.fab)

        // Language toggle
        langToggle.setOnCheckedChangeListener { _, isChecked ->
            langLabel.text = if (isChecked) "ಕನ್ನಡ" else "English"
            viewModel.setKannadaMode(isChecked)
        }

        // Search
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.search(newText ?: "")
                return true
            }
        })

        // FAB - Add contact (opens system contacts app)
        fab.setOnClickListener {
            val intent = Intent(Intent.ACTION_INSERT)
            intent.type = "vnd.android.cursor.dir/contact"
            startActivity(intent)
        }
    }

    private fun setupRecyclerView() {
        adapter = ContactsAdapter(
            getDisplayName = { contact -> viewModel.getDisplayName(contact) },
            onClick = { contact -> openDetail(contact) },
            onCallClick = { contact -> makeCall(contact) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun observeViewModel() {
        viewModel.uiState.observe(this) { state ->
            when (state) {
                is UiState.Loading -> {
                    progressBar.visibility = View.VISIBLE
                    recyclerView.visibility = View.GONE
                    emptyView.visibility = View.GONE
                    statusBar.text = "Loading contacts..."
                }
                is UiState.PermissionNeeded -> {
                    progressBar.visibility = View.GONE
                    statusBar.text = "Permission needed"
                }
                is UiState.TranslatorDownloading -> {
                    statusBar.text = "⬇ Downloading Kannada language model..."
                    statusBar.visibility = View.VISIBLE
                }
                is UiState.Success -> {
                    progressBar.visibility = View.GONE
                    statusBar.text = if (viewModel.isKannadaMode.value == true)
                        "ಕನ್ನಡ ಮೋಡ್ ಆನ್ | ${state.contacts.size} ಸಂಪರ್ಕಗಳು"
                    else
                        "${state.contacts.size} contacts"

                    if (state.contacts.isEmpty()) {
                        recyclerView.visibility = View.GONE
                        emptyView.visibility = View.VISIBLE
                    } else {
                        recyclerView.visibility = View.VISIBLE
                        emptyView.visibility = View.GONE
                        val sectionedList = SectionBuilder.buildSectionedList(state.contacts) {
                            viewModel.getDisplayName(it)
                        }
                        adapter.submitList(sectionedList)
                    }
                }
                is UiState.Error -> {
                    progressBar.visibility = View.GONE
                    statusBar.text = "Error: ${state.message}"
                    Snackbar.make(recyclerView, state.message, Snackbar.LENGTH_LONG).show()
                }
            }
        }

        viewModel.isKannadaMode.observe(this) { isKannada ->
            // Refresh adapter when mode changes
            val current = viewModel.uiState.value
            if (current is UiState.Success) {
                val sectionedList = SectionBuilder.buildSectionedList(current.contacts) {
                    viewModel.getDisplayName(it)
                }
                adapter.submitList(sectionedList)
            }
        }
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            == PackageManager.PERMISSION_GRANTED) {
            startLoadingData()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CONTACTS),
                PERMISSION_REQUEST
            )
        }
    }

    private fun startLoadingData() {
        viewModel.loadContacts()
        viewModel.prepareTranslator()
    }

    private fun openDetail(contact: Contact) {
        val intent = Intent(this, ContactDetailActivity::class.java)
        intent.putExtra(EXTRA_CONTACT_ID, contact.id)
        intent.putExtra(EXTRA_IS_KANNADA, viewModel.isKannadaMode.value ?: false)
        // Pass contact data
        ContactHolder.currentContact = contact
        ContactHolder.currentDisplayName = viewModel.getDisplayName(contact)
        startActivity(intent)
    }

    private fun makeCall(contact: Contact) {
        val number = contact.phoneNumbers.firstOrNull()?.number ?: return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            == PackageManager.PERMISSION_GRANTED) {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
            startActivity(intent)
        } else {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
            startActivity(intent)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startLoadingData()
        } else {
            Snackbar.make(
                findViewById(android.R.id.content),
                "Contacts permission is needed to show contacts",
                Snackbar.LENGTH_LONG
            ).show()
        }
    }
}

// Simple holder to pass contact data between activities
object ContactHolder {
    var currentContact: Contact? = null
    var currentDisplayName: String = ""
}
